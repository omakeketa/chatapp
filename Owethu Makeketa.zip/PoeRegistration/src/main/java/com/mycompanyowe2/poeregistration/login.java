/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompanyowe2.poeregistration;

/**
 *
 * @author RC_Student_lab
 */
class login {
    
    //Feilds to store user credentialsand personal info
    private String User;
    private String Pass;
    private String UserName;
    private String UserLast;
    private String CellPhone;
    
    //Setters for registration details
    
    public String getUser() {
        return User;
    }
    
    public String getPass() {
        return Pass;
    }
    
    public String getUserName() {
        return UserName;
    }
    
    public String getUserLast() {
        return UserLast;
    }
    
    
    
    public String getCellPhone() {
        return CellPhone;
    }
    
    public void setUser(String User) {
        this.User = User;
       
    } 
    
    public void setPass(String Pass) {
        this.Pass = Pass;
    }
    
    public void setUserName(String UserName) {
        this.UserName = UserName;
    }
    
    public void setUserLast(String UserLast ) {
        this.UserLast = UserLast;
    }
    
    public void setCellPhone(String CellPhone) {
        this.CellPhone = CellPhone;
    }
    
    
    
    
    //Method to check if the usename is valid (max 5 characters and contains "_")
    public boolean checkUserName() {
        return UserName.length() <= 5 && UserName.contains("_");
    }
    
    //Method to check password complexity(must have uppercase, number, and special character)
    public boolean checkPasswordComplexity() {
        boolean hasNumber = false, hasSpecial = false, hasUpper = false;
        
        if(UserLast.length() >= 8) {
            for (char ch : UserLast.toCharArray()) {
                if (Character.isUpperCase(ch)) {
                    hasUpper = true;
                }
            }
        }
        return hasUpper && hasNumber && hasSpecial;
    }
    
    //Method to validate phone number format (must include international code)
    public boolean checkCellPhone() {
        if (CellPhone.matches("\\+\\d{1,3}\\d{10}")) {
            System.out.println("Cell phone number successfully added.");
            return true;
        }else{
            System.out.println("Cell phone number incorrectly formatted or does not containinternational code.");
            return false;
        }
    }

    
    //Method to attempt user registration and display feedback
    public String registerUser() {
        if (checkUserName()) {
            System.out.println("Username successfully captured");
        }else{
            System.out.println("Username is not correctly formatted, please ensure that your Username contains an underscore");
        }
        
        if (checkPasswordComplexity()) {
            System.out.println("Pasword successfully captured");
        }else{
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least the uppercase, number, and special character");
        }
        
        if (checkUserName ()  && checkPasswordComplexity()) {
            System.out.println("The two above conditions have been met, and the user has been registered successfully ");
        }
        
        return "";
    }
    
    //Method to verify if login credentials match
       public boolean loginUser() {
           return UserName.equals(User) && UserLast.equals(Pass);
    }
       
    //Method to return login status and welcome message
       public String returnLoginStatus() {
           if (loginUser()) {
               System.out.println("successful Login");
               System.out.println("Welcome " + UserName + " " + UserLast + ". It is great to see you again.");
           }else{
               System.out.println("A Failed Login");
               System.out.println("UserName, Password, or Phone Number incorrect, please try again");
           }
           return "";
           
           

  
           
        }
    }


    

