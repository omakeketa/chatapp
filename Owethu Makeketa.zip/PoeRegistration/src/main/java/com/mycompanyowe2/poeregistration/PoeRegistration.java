/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompanyowe2.poeregistration;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class PoeRegistration {
    
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
       login reg = new login ();
       
       System.out.println("\n=== User Login ===");
       
       //=== User Registration ===
       System.out.print("Enter your username: ");
       String username = input.next();
       reg.setUserName(username);
       
       System.out.print("Enter your password: ");
       String password = input.next();
       reg.setUserLast(password);
       
       System.out.print("Enter your cell phone number (e.g. +27677308990):");
       String phone = input.next();
       reg.setCellPhone(phone);
       
       //set registration info
       
       //validate phone, username, and password
       
       //=== Proceed to login if registration is successful ===
       if (reg.checkUserName() && reg.checkPasswordComplexity()) {
           System.out.println("Password and username correctly formatted");
       }else{
           System.out.println("Password and username are incorrectly formatted");
       }    
       
       System.out.println("=======================LOGIN========================");
       
       System.out.print("Enter your username: ");
         String LoginUser = input.next();
         reg.setUser(LoginUser);
         
       System.out.print("Enter your password: ");
       String LoginPass = input.next();
       reg.setPass(LoginPass);
       
       if(reg.loginUser()) {
           System.out.println("successfully login");
       }else{
           System.out.println("unsuccessfully logged in");
       }
       
       input.close();
       
    }
}


    
